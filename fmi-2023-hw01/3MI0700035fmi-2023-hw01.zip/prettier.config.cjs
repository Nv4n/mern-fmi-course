/** @type {import("prettier").Config} */
const config = {
	useTabs: true,
	tabWidth: 4,
};

module.exports = config;
